package com.mkv.secondnote;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SplashActivity extends AppCompatActivity implements View.OnKeyListener {

    private static final String TAG="pin";
    ImageView i1,i2,i3,i4;
    EditText enterPin;
    LinearLayout backgroundLayout;
    static SharedPreferences sharedPreferences;
    private static String answer;
    TextView create_edit;
    TextView changePin;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);



        //definition of sharedPreference
        sharedPreferences=this.getSharedPreferences
                ("com.mkv.pin", Context.MODE_PRIVATE);

        create_edit=(TextView) findViewById(R.id.no_textview_1);
        if(example().isEmpty()) {
            create_edit.setText("Create Pin");
        }else{create_edit.setText("Enter Pin");}

        //changePin=(TextView) findViewById(R.id.pinChange);
        //changePin.setVisibility(View.GONE);

        //changePin.setOnClickListener(new View.OnClickListener() {
            //@Override
            //public void onClick(View view) {
              //  if(example().isEmpty()){
                //    Toast.makeText(getApplication(),"Please create pin"
                  //  ,Toast.LENGTH_SHORT).show();
                //}else{
                  ///  create_edit.setText("Confirm Pin");
                    //if(enterPin.getText().toString().equals(example())){
                      //  create_edit.setText("Enter New Pin");


      //  }//
                //}}});//
//end of onclick

        i1=(ImageView) findViewById(R.id.imageview_circle1);
        i2=(ImageView) findViewById(R.id.imageview_circle2);
        i3=(ImageView) findViewById(R.id.imageview_circle3);
        i4=(ImageView) findViewById(R.id.imageview_circle4);

        enterPin=(EditText) findViewById(R.id.enter_pin);
        enterPin.requestFocus();
        enterPin.setInputType(InputType.TYPE_CLASS_NUMBER);
        enterPin.setFocusableInTouchMode(true);

        enterPin.setOnKeyListener(this);
        backgroundLayout=(LinearLayout) findViewById(R.id.no_linear_1);
        backgroundLayout.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                if(view.getId()==R.id.no_linear_1
                        || view.getId()==R.id.no_linear_2
                        || view.getId()==R.id.no_textview_1
                        ||view.getId()==R.id.no_linear_main){
                    InputMethodManager inputMethodManager=(InputMethodManager)
                            getSystemService(INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(getCurrentFocus()
                            .getWindowToken(),0);
                }
            }
        });


        enterPin.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                switch (editable.length()) {
                    case 4:
                        i4.setImageResource(R.drawable.circle2);
                        break;
                    case 3:
                        i4.setImageResource(R.drawable.circle);
                        i3.setImageResource(R.drawable.circle2);
                        break;
                    case 2:
                        i3.setImageResource(R.drawable.circle);
                        i2.setImageResource(R.drawable.circle2);
                        break;
                    case 1:
                        i2.setImageResource(R.drawable.circle);
                        i1.setImageResource(R.drawable.circle2);
                        break;
                    default:
                        i1.setImageResource(R.drawable.circle);
                }
            }
        });

    }

    @Override
    public boolean onKey(View view, int i, KeyEvent keyEvent) {

        if(i == KeyEvent.KEYCODE_ENTER && keyEvent.getAction() == KeyEvent.ACTION_DOWN) {

            String text = enterPin.getText().toString();

            if (text.length() != 4) {

                Toast.makeText(this, "Please" +
                        " enter 4 digit pin.", Toast.LENGTH_SHORT).show();
            }
            if (text.length() == 4) {
                if(example().isEmpty()) {
                    savePin(text);
                }else{
                    if(example().equals(text)){
                        Intent intent=new Intent(this,MainActivity.class);
                        startActivity(intent);
                        this.finish();
                    }else{
                        Toast.makeText(this, "WRONG PIN"
                                , Toast.LENGTH_SHORT).show();

                    }
                }//end of else


            }
        }
        //write code about what happens on clicking done button

        return false;
    }

    public void savePin( String myPin){
        sharedPreferences.edit().putString("passwors",myPin).apply();

        Toast.makeText(this,"Pin created successfully",Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
        this.finish();
        Log.i("ad","da");



    }
    public static String example(){
        answer=sharedPreferences.getString("passwors","");
        return answer;
    }

  //write code about what happens on clicking done button
}




